# Floating Assistant Pro — Android Studio (Gradle) Project

A professional rebuild of Floating Assistant v1 for vivo Y17s / Android 15.
This is a real Android Studio Gradle project (not the previous aapt2
one-off build): settings.gradle, app/build.gradle, Gradle wrapper,
Kotlin sources, Room database, AndroidX + Material libraries and ML Kit.

## What is in here

- `app/src/main/java/com/floatingassistant/` — Kotlin sources:
  - `MainActivity.kt` — Home / Notes / History / Apps / Setting tabs
  - `PermissionSetupActivity.kt` — step-by-step permission setup AND
    the permanent permission-status screen (open it again from Setting)
  - `PrivacyActivity.kt` — plain Roman Urdu privacy screen
  - `PermissionHelper.kt` — the correct Android 15 route for every
    permission (runtime dialog vs overlay settings vs Accessibility
    settings vs battery settings), plus "Don't ask again" handling
  - `FloatingService.kt`, `PlaybackService.kt` (foreground,
    mediaPlayback), `ReadAloudAccessibilityService.kt`
  - `AppDatabase.kt` — Room: notes, copy history, assistant log.
    There is NO expiry column, NO auto-delete job and NO cleanup code
    anywhere. Deletion happens only from a user delete button.
  - `PinStore.kt` — notebook PIN in EncryptedSharedPreferences, with
    an honest plain fallback flag if encryption cannot be created
  - `TTSHelper.kt`, `TranslateHelper.kt` (ML Kit + labelled dictionary
    fallback), `OtpUtil.kt` (memory only), `OtpReceiver.kt`,
    `OtpActivity.kt`, `EmailActivity.kt`, `NoteEditActivity.kt`
    (note + photo + ML Kit OCR), `ReminderReceiver.kt`,
    `ExportImportHelper.kt` (ZIP backup, button-only)
- `app/src/main/res/` — layouts, Material/DayNight theme, adaptive icon
- `app/build.gradle` — target SDK 35, min SDK 26, versionCode 2

## Honest limits (also shown inside the app)

- Real Google Drive backup: NOT implemented — no Google OAuth client
  exists. Working backup is Export/Import ZIP, which the user saves to
  Drive manually. No fake Google login is shown.
- Real Gmail: NOT implemented for the same reason. The email screen is
  paste-text only and says so.
- This APK was NOT tested on a real vivo Y17s (no device/emulator on
  the build VM). Phone testing by the user is still required.
- A sideloaded test APK can still trigger a Play Protect prompt on
  first install, even when built professionally: unknown developer +
  sensitive permissions (SMS, Accessibility, overlay). A Play Store
  listing is the separate step that reduces this.

## Rebuild in Android Studio

1. Open this folder in Android Studio.
2. Let Gradle sync (needs normal Maven/Google access for the first
   sync; afterwards it works offline from the Gradle cache).
3. Run > Run 'app', or Build > Build App Bundle(s) / APK(s) >
   Build APK(s) for a debug APK.

## Rebuild from the command line

```bash
export ANDROID_HOME=$HOME/android-sdk
export ANDROID_SDK_ROOT=$HOME/android-sdk
cd floating-assistant-pro
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

If Gradle cannot reach Maven through a proxy, set the proxy in
`~/.gradle/gradle.properties` (NOT in this project):

```properties
systemProp.http.proxyHost=<proxy host>
systemProp.http.proxyPort=3128
systemProp.https.proxyHost=<proxy host>
systemProp.https.proxyPort=3128
systemProp.http.nonProxyHosts=localhost|127.0.0.1
systemProp.https.nonProxyHosts=localhost|127.0.0.1
```

Never put a password, key or token in this project.
