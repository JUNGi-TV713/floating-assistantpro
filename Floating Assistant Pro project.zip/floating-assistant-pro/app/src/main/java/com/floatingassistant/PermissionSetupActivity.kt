package com.floatingassistant

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * First-launch permission setup, and the permanent Permission Status
 * screen (reachable again from MainActivity > Setting).
 *
 * One permission per step, in easy Roman Urdu:
 * plain name, WHY it is needed, what will NOT work if denied, live
 * status, Allow button, Skip button, Re-check button, and a button
 * that opens the app's system Settings page (for "Don't ask again").
 *
 * Runtime permissions go through the normal Android dialog.
 * Overlay / Accessibility / Battery go to their correct system
 * settings screens — there is no runtime dialog for those on
 * Android 15, and this screen does not pretend otherwise.
 */
class PermissionSetupActivity : AppCompatActivity() {
    private val steps = PermissionHelper.steps()
    private var index = 0

    private lateinit var txtTitle: TextView
    private lateinit var txtWhy: TextView
    private lateinit var txtIfDenied: TextView
    private lateinit var txtStatus: TextView
    private lateinit var txtProgress: TextView

    private val runtimeLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { render() }

    private val settingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { render() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permission_setup)
        txtTitle = findViewById(R.id.txtPermTitle)
        txtWhy = findViewById(R.id.txtPermWhy)
        txtIfDenied = findViewById(R.id.txtPermIfDenied)
        txtStatus = findViewById(R.id.txtPermStatus)
        txtProgress = findViewById(R.id.txtPermProgress)

        click(R.id.btnPermAllow, "Ijazat dein") { onAllow() }
        click(R.id.btnPermRecheck, "Dobara Check karo") { render() }
        click(R.id.btnPermSkip, "Choro, agla") { next() }
        click(R.id.btnPermSettings, "System Setting kholo") {
            PermissionHelper.openAppSettings(this)
        }
        click(R.id.btnPermPrev, "Pichla") {
            if (index > 0) {
                index--
                render()
            }
        }
        click(R.id.btnPermDone, "Setup khatam karo") {
            Prefs.setSetupDone(this, true)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        render()
    }

    override fun onResume() {
        super.onResume()
        // Returning from a system settings screen: re-check live status.
        render()
    }

    private fun onAllow() {
        val step = steps[index]
        when (step.kind) {
            PermissionHelper.Kind.RUNTIME -> {
                if (step.runtimePermissions.isEmpty()) {
                    Toast.makeText(this, "Iske liye alag ijazat nahi chahiye", Toast.LENGTH_SHORT).show()
                    next()
                    return
                }
                if (PermissionHelper.isPermanentlyDenied(this, step)) {
                    Toast.makeText(
                        this,
                        "Ye permission pehle mana ho chuki hai. Neeche 'App ki System Setting kholo' dabayein aur wahan se dein.",
                        Toast.LENGTH_LONG
                    ).show()
                    return
                }
                runtimeLauncher.launch(step.runtimePermissions.toTypedArray())
            }
            PermissionHelper.Kind.OVERLAY,
            PermissionHelper.Kind.ACCESSIBILITY,
            PermissionHelper.Kind.BATTERY -> {
                val intent = PermissionHelper.settingsIntent(this, step)
                if (intent != null) {
                    settingsLauncher.launch(intent)
                }
            }
            PermissionHelper.Kind.INFO -> {
                Toast.makeText(this, "Theek hai, agla step dekhein", Toast.LENGTH_SHORT).show()
                next()
            }
        }
    }

    private fun next() {
        if (index < steps.size - 1) {
            index++
            render()
        } else {
            Prefs.setSetupDone(this, true)
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun render() {
        val step = steps[index]
        txtTitle.text = step.title + if (step.optional) " — OPTIONAL" else ""
        txtWhy.text = "Kyun chahiye? " + step.why
        txtIfDenied.text = "Agar na mile to: " + step.ifDenied
        txtStatus.text = "Status: " + PermissionHelper.statusText(this, step)
        txtProgress.text = "${index + 1} / ${steps.size}"
        findViewById<View>(R.id.btnPermPrev).isEnabled = index > 0
        TTSHelper.speakLabel(this, step.title)
    }

    private fun click(id: Int, label: String, action: () -> Unit) {
        findViewById<Button>(id).setOnClickListener {
            TTSHelper.speakLabel(this, label)
            action()
        }
    }
}
