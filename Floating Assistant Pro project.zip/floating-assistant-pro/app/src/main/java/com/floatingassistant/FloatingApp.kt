package com.floatingassistant

import android.app.Application

class FloatingApp : Application() {
    override fun onCreate() {
        super.onCreate()
        TTSHelper.init(this)
    }
}
