package com.floatingassistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Main screen: Home / Notes / History / Apps / Setting tabs, in easy
 * Roman Urdu, with large buttons. Every button speaks its name aloud
 * through [click] before running its action.
 *
 * Permission rule (enforced everywhere here): a feature that needs a
 * permission checks it first. If it is missing, the user gets the
 * Roman Urdu reason and a button to the correct settings screen —
 * never a silent failure, never a crash.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var db: AppDatabase
    private lateinit var edtText: EditText
    private lateinit var edtCommand: EditText
    private lateinit var edtSearch: EditText
    private lateinit var edtPin: EditText
    private lateinit var txtStatus: TextView
    private lateinit var spLang: Spinner
    private lateinit var spSpeed: Spinner
    private lateinit var spButtonSize: Spinner
    private lateinit var chkDark: CheckBox
    private lateinit var chkLock: CheckBox
    private lateinit var chkTapRead: CheckBox
    private lateinit var lvNotes: ListView
    private lateinit var lvHistory: ListView
    private lateinit var lvApps: ListView
    private lateinit var lvLog: ListView

    private var curNotes: List<NoteEntity> = emptyList()
    private var curHist: List<HistoryEntity> = emptyList()
    private var lastClipboard = ""
    private var firstResume = true
    private var voiceTarget = "text"

    private val appPkgs = arrayOf(
        "com.whatsapp", "com.google.android.gm", "com.google.android.youtube",
        "com.android.chrome", "com.google.android.apps.maps"
    )
    private val appNames = arrayOf("WhatsApp", "Gmail", "YouTube", "Chrome Browser", "Google Maps")

    private val voiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode != RESULT_OK) return@registerForActivityResult
        val results = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        val spoken = results?.firstOrNull() ?: return@registerForActivityResult
        if (voiceTarget == "search") {
            edtSearch.setText(spoken)
            refreshNotes()
        } else {
            edtText.setText(spoken)
        }
    }

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { ExportImportHelper.exportZip(this@MainActivity, uri, db) }
                toast("Backup export ho gaya. Is file ko khud Drive mein save karein.")
            } catch (e: Exception) {
                toast("Export nahi hua: ${e.message}")
            }
        }
    }

    private val importLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        lifecycleScope.launch {
            try {
                val msg = withContext(Dispatchers.IO) {
                    ExportImportHelper.importZip(this@MainActivity, uri, db)
                }
                toast(msg)
                refreshAll()
            } catch (e: Exception) {
                toast("Import nahi hua: ${e.message}")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Prefs.dark(this)) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = AppDatabase.get(this)

        edtText = findViewById(R.id.edtText)
        edtCommand = findViewById(R.id.edtCommand)
        edtSearch = findViewById(R.id.edtSearch)
        edtPin = findViewById(R.id.edtPin)
        txtStatus = findViewById(R.id.txtStatus)
        spLang = findViewById(R.id.spLang)
        spSpeed = findViewById(R.id.spSpeed)
        spButtonSize = findViewById(R.id.spButtonSize)
        chkDark = findViewById(R.id.chkDark)
        chkLock = findViewById(R.id.chkLock)
        chkTapRead = findViewById(R.id.chkTapRead)
        lvNotes = findViewById(R.id.lvNotes)
        lvHistory = findViewById(R.id.lvHistory)
        lvApps = findViewById(R.id.lvApps)
        lvLog = findViewById(R.id.lvAssistantLog)

        setupSpinner(spLang, arrayOf("Auto", "Urdu", "English"), Prefs.lang(this)) {
            Prefs.setLang(this, it)
        }
        setupSpinner(spSpeed, arrayOf("Dheemi", "Normal", "Tez"), Prefs.speedName(this)) {
            Prefs.setSpeedName(this, it)
        }
        setupSpinner(
            spButtonSize,
            arrayOf("Chota", "Medium", "Bara"),
            Prefs.buttonSizeName(this)
        ) { Prefs.setButtonSizeName(this, it) }

        chkDark.isChecked = Prefs.dark(this)
        chkDark.setOnCheckedChangeListener { _, checked ->
            Prefs.setDark(this, checked)
            AppCompatDelegate.setDefaultNightMode(
                if (checked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            )
            recreate()
        }
        chkLock.isChecked = Prefs.lockOn(this)
        chkLock.setOnCheckedChangeListener { _, checked -> Prefs.setLockOn(this, checked) }
        chkTapRead.isChecked = Prefs.tapToRead(this)
        chkTapRead.setOnCheckedChangeListener { _, checked ->
            if (checked && !PermissionHelper.isAccessibilityEnabled(this)) {
                toast("Pehle Permission Setup mein Accessibility on karein, phir ye checkbox lagayein.")
                chkTapRead.isChecked = false
                return@setOnCheckedChangeListener
            }
            Prefs.setTapToRead(this, checked)
        }

        // Tabs
        click(R.id.btnTabHome, "Home") { showTab("home") }
        click(R.id.btnTabNotes, "Notes") { showTab("notes") }
        click(R.id.btnTabHistory, "History") { showTab("history") }
        click(R.id.btnTabApps, "Apps") { showTab("apps") }
        click(R.id.btnTabSettings, "Setting") { showTab("settings") }

        // Home actions
        click(R.id.btnSpeak, "Sunao") {
            val t = edtText.text.toString()
            if (t.isBlank()) {
                toast("Pehle text likhein ya paste karein")
                return@click
            }
            saveHistoryOnce(t)
            speakViaService(t)
            setStatus("Sun raha hai...")
        }
        click(R.id.btnStop, "Roko") {
            TTSHelper.stop()
            stopService(Intent(this, PlaybackService::class.java))
            setStatus("Ruk gaya.")
        }
        click(R.id.btnSave, "Note mein Save karo") {
            val t = edtText.text.toString()
            if (t.isBlank()) {
                toast("Pehle text likhein")
                return@click
            }
            startActivity(Intent(this, NoteEditActivity::class.java).apply {
                putExtra("presetText", t)
            })
        }
        click(R.id.btnTranslate, "Translate karo") {
            val t = edtText.text.toString()
            if (t.isBlank()) return@click
            lifecycleScope.launch {
                val toUrdu = !t.any { it.code in 0x0600..0x06FF }
                val ml = TranslateHelper.mlTranslate(t, toUrdu)
                if (ml != null) {
                    edtText.setText(ml)
                    setStatus("ML Kit se translate hua hai.")
                    speakViaService("Translate ho gaya")
                } else {
                    edtText.setText(TranslateHelper.dictionaryTranslate(t))
                    setStatus("Limited dictionary translate hua hai. ML Kit model nahi mila, is liye poora translate nahi hua — ye fake poora translate nahi hai.")
                    speakViaService("Limited translate ho gaya")
                }
            }
        }
        click(R.id.btnSummary, "Chota Summary sunao") {
            val t = edtText.text.toString()
            if (t.isBlank()) return@click
            speakViaService(TranslateHelper.summary(t))
        }
        click(R.id.btnCopy, "Copy karo") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Text", edtText.text.toString()))
            saveHistoryOnce(edtText.text.toString())
            toast("Copy ho gaya")
        }
        click(R.id.btnShare, "Share karo") {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, edtText.text.toString())
            }
            startActivity(Intent.createChooser(i, "Share karein"))
        }
        click(R.id.btnVoice, "Bol kar likho") { startVoice("text") }
        click(R.id.btnPhoto, "Photo se Note banao") {
            startActivity(Intent(this, NoteEditActivity::class.java))
            toast("Photo Note mein lagayein, phir OCR button se text nikal sakte hain.")
        }
        click(R.id.btnScreenRead, "Screen ka text sunao") {
            if (!PermissionHelper.isAccessibilityEnabled(this)) {
                toast("Pehle Permission Setup mein Accessibility on karein, phir ye button dabayein.")
                startActivity(Intent(this, PermissionSetupActivity::class.java))
                return@click
            }
            if (!ReadAloudAccessibilityService.speakActiveWindow()) {
                toast("Screen par koi text nahi mila ya service abhi tayyar nahi.")
            }
        }
        click(R.id.btnAssistant, "Assistant se pucho") { runAssistant() }
        click(R.id.btnReminder, "Reminder lagao") {
            val t = edtText.text.toString().ifBlank { "Aapka reminder: waqt ho gaya hai" }
            scheduleReminder(t, 10 * 60 * 1000L)
        }
        click(R.id.btnMorning, "Pinned Notes ka Summary sunao") {
            lifecycleScope.launch {
                val pinned = db.noteDao().all().filter { it.pinned == 1 }
                val sb = StringBuilder("Aapke pinned notes: ")
                pinned.forEach { sb.append(it.title).append(". ") }
                speakViaService(sb.toString())
            }
        }

        // Notes tab
        click(R.id.btnVoiceSearch, "Bol kar dhoondo") { startVoice("search") }
        click(R.id.btnNewNote, "Naya Note likho") {
            startActivity(Intent(this, NoteEditActivity::class.java))
        }
        edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { refreshNotes() }
            override fun afterTextChanged(s: Editable?) {}
        })
        lvNotes.setOnItemClickListener { _, _, pos, _ ->
            val n = curNotes.getOrNull(pos) ?: return@setOnItemClickListener
            AlertDialog.Builder(this).setTitle(n.title)
                .setItems(arrayOf("Kholo", "Copy karo", "Pin badlo", "Delete karo")) { _, which ->
                    when (which) {
                        0 -> startActivity(Intent(this, NoteEditActivity::class.java).apply {
                            putExtra("noteId", n.id)
                        })
                        1 -> {
                            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("Note", n.body))
                            toast("Copy ho gaya")
                        }
                        2 -> lifecycleScope.launch {
                            db.noteDao().update(n.copy(pinned = if (n.pinned == 1) 0 else 1))
                            refreshNotes()
                        }
                        3 -> confirmDeleteNote(n)
                    }
                }.show()
        }

        // History tab
        click(R.id.btnClearHistory, "Sab History Delete karo") {
            AlertDialog.Builder(this)
                .setTitle("Sab history delete karein?")
                .setMessage("Ye sirf aapke is button se delete hogi. Koi auto-delete nahi hai.")
                .setPositiveButton("Haan, Delete karo") { _, _ ->
                    lifecycleScope.launch {
                        db.historyDao().deleteAll()
                        refreshHistory()
                    }
                }
                .setNegativeButton("Nahi", null)
                .show()
        }
        lvHistory.setOnItemClickListener { _, _, pos, _ ->
            val h = curHist.getOrNull(pos) ?: return@setOnItemClickListener
            AlertDialog.Builder(this).setTitle("History")
                .setItems(arrayOf("Dobara Copy karo", "Note mein Save karo", "Sunao", "Delete karo")) { _, which ->
                    when (which) {
                        0 -> {
                            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("History", h.text))
                            toast("Copy ho gaya")
                        }
                        1 -> startActivity(Intent(this, NoteEditActivity::class.java).apply {
                            putExtra("presetText", h.text)
                        })
                        2 -> speakViaService(h.text)
                        3 -> lifecycleScope.launch {
                            db.historyDao().deleteById(h.id)
                            refreshHistory()
                        }
                    }
                }.show()
        }

        // Apps tab
        click(R.id.btnFloating, "Floating Button On karo") {
            if (!Settings.canDrawOverlays(this)) {
                toast("Pehle 'Doosri apps ke upar dikhana' ki ijazat dein. Permission Setup khul raha hai.")
                startActivity(Intent(this, PermissionSetupActivity::class.java))
            } else {
                startService(Intent(this, FloatingService::class.java))
                toast("Floating button on ho gaya")
            }
        }
        click(R.id.btnEmail, "Email Window kholo") {
            startActivity(Intent(this, EmailActivity::class.java))
        }
        click(R.id.btnOtpManual, "OTP Copy karo") {
            val otp = OtpUtil.findOtp(edtText.text.toString())
            if (otp == null) {
                toast("Pehle OTP wala text Home mein paste karein")
                showTab("home")
                return@click
            }
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("OTP", otp))
            toast("OTP copy ho gaya, kahin save nahi hua")
        }
        click(R.id.btnSplit, "Split Screen ki koshish karo") {
            val ok = ReadAloudAccessibilityService.toggleSplitScreen()
            toast(
                if (ok) "Split screen ki koshish ho rahi hai"
                else "Split screen ke liye Accessibility on karein, ya phone ki Recent Apps mein app ko split screen karein. Har app choti window mein nahi khulti."
            )
        }
        lvApps.setOnItemClickListener { _, _, pos, _ ->
            val li = packageManager.getLaunchIntentForPackage(appPkgs[pos])
            if (li != null) startActivity(li)
            else toast("${appNames[pos]} is phone mein install nahi hai")
        }

        // Settings tab
        click(R.id.btnPermissionSetup, "Permission Setup kholo") {
            startActivity(Intent(this, PermissionSetupActivity::class.java))
        }
        click(R.id.btnPrivacy, "Privacy parho") {
            startActivity(Intent(this, PrivacyActivity::class.java))
        }
        click(R.id.btnGoogle, "Google Sign-in") {
            AlertDialog.Builder(this)
                .setTitle("Google Sign-in — setup baqi hai")
                .setMessage("Is test mein koi Google OAuth client nahi hai, is liye fake login nahi dikhaya jayega. Backup ke liye neeche Export file bana kar usay khud Google Drive mein save karein. Ye agla step hai, iske liye aapke Google account ki approval chahiye hogi.")
                .setPositiveButton("Theek hai", null)
                .show()
        }
        click(R.id.btnExport, "Backup Export karo") {
            exportLauncher.launch("FloatingAssistantBackup.zip")
        }
        click(R.id.btnImport, "Backup Import karo") {
            importLauncher.launch(arrayOf("application/zip"))
        }
        click(R.id.btnSetPin, "PIN Save karo") {
            val pin = edtPin.text.toString()
            if (pin.length != 4) {
                toast("4 number ka PIN likhein")
                return@click
            }
            PinStore.setPin(this, pin)
            toast(
                if (PinStore.isEncrypted(this)) "PIN save ho gaya (encrypted storage mein)."
                else "PIN save ho gaya, lekin is phone par encrypted storage nahi bana — sensitive note ke liye ehtiyat karein."
            )
        }
        click(R.id.btnUnlock, "Fingerprint se kholo") { tryBiometric() }

        val tab = intent.getStringExtra("tab")
        if (tab != null) showTab(tab)
        if (!Prefs.setupDone(this)) {
            startActivity(Intent(this, PermissionSetupActivity::class.java))
        }
        refreshAll()
    }

    private fun setupSpinner(
        spinner: Spinner,
        items: Array<String>,
        current: String,
        onSelect: (String) -> Unit
    ) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setSelection(items.indexOf(current).coerceAtLeast(0))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            private var first = true
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (first) {
                    first = false
                    return
                }
                onSelect(items[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun tryBiometric() {
        try {
            val executor = ContextCompat.getMainExecutor(this)
            val prompt = BiometricPrompt(
                this, executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        Prefs.setUnlocked(this@MainActivity, true)
                        refreshNotes()
                        toast("Khul gaya")
                    }
                }
            )
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle("Fingerprint se kholo")
                .setDescription("Notebook kholne ke liye fingerprint dein")
                .setNegativeButtonText("Cancel")
                .build()
            prompt.authenticate(info)
        } catch (e: Exception) {
            toast("Is phone mein fingerprint nahi ya ijazat nahi: PIN use karein")
        }
    }

    private fun scheduleReminder(text: String, delayMs: Long) {
        val ri = Intent(this, ReminderReceiver::class.java).apply { putExtra("text", text) }
        val pi = PendingIntent.getBroadcast(
            this, 0, ri,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            am.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + delayMs,
                pi
            )
            toast("Reminder 10 minute baad lag gaya")
        } catch (e: Exception) {
            toast("Reminder ki ijazat nahi mili: ${e.message}")
        }
    }

    private fun runAssistant() {
        val orig = edtCommand.text.toString()
        val cmd = orig.lowercase()
        if (cmd.isBlank()) {
            toast("Pehle hukum likhein")
            return
        }
        val action = when {
            cmd.contains("save") || cmd.contains("note") -> "Note save karna"
            cmd.contains("sunao") || cmd.contains("suna") -> "Text sunana"
            cmd.contains("reminder") -> "Reminder lagana"
            cmd.contains("whatsapp") -> "WhatsApp kholna"
            cmd.contains("gmail") || cmd.contains("email") -> "Email window kholna"
            cmd.contains("youtube") -> "YouTube kholna"
            else -> {
                toast("Ye hukum samajh nahi aaya. Dobara asan lafzon mein likhein.")
                return
            }
        }
        // Permission-gated: ask first, act only on Yes, log only then.
        AlertDialog.Builder(this)
            .setTitle("Assistant — pehle puchega")
            .setMessage("Main ye kaam kar dun? $action")
            .setPositiveButton("Haan, kar do") { _, _ ->
                doAssistantAction(cmd)
                lifecycleScope.launch {
                    db.assistantLogDao().insert(AssistantLogEntity(action = action))
                    refreshLog()
                }
                toast("Ho gaya.")
            }
            .setNegativeButton("Nahi", null)
            .show()
    }

    private fun doAssistantAction(cmd: String) {
        when {
            cmd.contains("save") || cmd.contains("note") -> {
                val t = edtText.text.toString()
                if (t.isNotBlank()) {
                    lifecycleScope.launch {
                        db.noteDao().insert(
                            NoteEntity(title = "Assistant Note", body = t, category = "Kaam ki baatein")
                        )
                    }
                }
            }
            cmd.contains("sunao") || cmd.contains("suna") -> speakViaService(edtText.text.toString())
            cmd.contains("reminder") -> scheduleReminder("Assistant reminder: waqt ho gaya hai", 10 * 60 * 1000L)
            cmd.contains("whatsapp") -> launchApp("com.whatsapp")
            cmd.contains("gmail") || cmd.contains("email") ->
                startActivity(Intent(this, EmailActivity::class.java))
            cmd.contains("youtube") -> launchApp("com.google.android.youtube")
        }
    }

    private fun launchApp(pkg: String) {
        val li = packageManager.getLaunchIntentForPackage(pkg)
        if (li != null) startActivity(li) else toast("Ye app install nahi hai")
    }

    private fun confirmDeleteNote(n: NoteEntity) {
        AlertDialog.Builder(this)
            .setTitle("Delete karein?")
            .setMessage("Ye note sirf aapke is button se delete hoga.")
            .setPositiveButton("Haan, Delete karo") { _, _ ->
                lifecycleScope.launch {
                    db.noteDao().deleteById(n.id)
                    refreshNotes()
                }
            }
            .setNegativeButton("Nahi", null)
            .show()
    }

    private fun startVoice(target: String) {
        voiceTarget = target
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK")
        }
        try {
            voiceLauncher.launch(i)
        } catch (e: Exception) {
            toast("Is phone mein voice input nahi mila")
        }
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
        // Copy -> "Sunau?" check: only when returning to the app, and only
        // once per new clipboard text. Never writes OTP to history.
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            if (cm.hasPrimaryClip() && cm.primaryClip!!.itemCount > 0) {
                val t = cm.primaryClip!!.getItemAt(0).text?.toString()
                if (!t.isNullOrBlank() && t != lastClipboard && !firstResume) {
                    lastClipboard = t
                    val clip = t
                    AlertDialog.Builder(this)
                        .setTitle("Sunau?")
                        .setMessage("Aapne ye text copy kiya hai, kya main isay parh kar sunau?")
                        .setPositiveButton("Haan, Sunao") { _, _ ->
                            saveHistoryOnce(clip)
                            edtText.setText(clip)
                            speakViaService(clip)
                        }
                        .setNegativeButton("Nahi") { _, _ -> saveHistoryOnce(clip) }
                        .show()
                } else if (t != null) {
                    lastClipboard = t
                }
            }
        } catch (ignored: Exception) {
        }
        firstResume = false
        intent.getStringExtra("tab")?.let { showTab(it) }
    }

    private fun saveHistoryOnce(t: String) {
        if (t.isBlank()) return
        lifecycleScope.launch {
            val h = db.historyDao().all()
            if (h.isNotEmpty() && h[0].text == t) return@launch
            db.historyDao().insert(HistoryEntity(text = t))
            refreshHistory()
        }
    }

    private fun showTab(tab: String) {
        findViewById<View>(R.id.section_home).visibility =
            if (tab == "home") View.VISIBLE else View.GONE
        if (tab == "notes") {
            if (Prefs.lockOn(this) && !Prefs.unlocked(this)) {
                askPin()
                return
            }
            findViewById<View>(R.id.section_notes).visibility = View.VISIBLE
        } else {
            findViewById<View>(R.id.section_notes).visibility = View.GONE
        }
        findViewById<View>(R.id.section_history).visibility =
            if (tab == "history") View.VISIBLE else View.GONE
        findViewById<View>(R.id.section_apps).visibility =
            if (tab == "apps") View.VISIBLE else View.GONE
        findViewById<View>(R.id.section_settings).visibility =
            if (tab == "settings") View.VISIBLE else View.GONE
        refreshAll()
    }

    private fun askPin() {
        val pinView = EditText(this).apply {
            inputType =
                android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle("Notebook Lock hai")
            .setMessage("PIN likhein ya Setting mein Fingerprint dabayein")
            .setView(pinView)
            .setPositiveButton("Kholo") { _, _ ->
                val pin = PinStore.getPin(this)
                if (pinView.text.toString() == pin && pin.isNotEmpty()) {
                    Prefs.setUnlocked(this, true)
                    findViewById<View>(R.id.section_notes).visibility = View.VISIBLE
                    refreshNotes()
                } else {
                    toast("PIN ghalat hai")
                }
            }
            .setNegativeButton("Wapas", null)
            .show()
    }

    private fun refreshAll() {
        refreshNotes()
        refreshHistory()
        refreshApps()
        refreshLog()
    }

    private fun refreshNotes() {
        lifecycleScope.launch {
            val q = edtSearch.text.toString()
            curNotes = if (q.isBlank()) db.noteDao().all() else db.noteDao().search(q)
            val items = curNotes.map { n ->
                (if (n.pinned == 1) "[PIN] " else "") + n.title + " — " + n.category
            }
            lvNotes.adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_list_item_1,
                items
            )
        }
    }

    private fun refreshHistory() {
        lifecycleScope.launch {
            curHist = db.historyDao().all()
            val items = curHist.map { h ->
                if (h.text.length > 80) h.text.substring(0, 80) + "..." else h.text
            }
            lvHistory.adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_list_item_1,
                items
            )
        }
    }

    private fun refreshApps() {
        val items = appPkgs.mapIndexed { i, pkg ->
            val inst = packageManager.getLaunchIntentForPackage(pkg) != null
            appNames[i] + if (inst) " — kholo" else " — install nahi hai"
        }
        lvApps.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, items)
    }

    private fun refreshLog() {
        lifecycleScope.launch {
            val items = db.assistantLogDao().recent().map { it.action }
            lvLog.adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_list_item_1,
                items
            )
        }
    }

    private fun speakViaService(text: String) {
        if (text.isBlank()) return
        val i = Intent(this, PlaybackService::class.java).apply {
            putExtra("text", text)
            putExtra("mode", Prefs.lang(this@MainActivity))
        }
        startService(i)
    }

    private fun click(id: Int, label: String, action: () -> Unit) {
        findViewById<Button>(id).setOnClickListener {
            TTSHelper.speakLabel(this, label)
            action()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun setStatus(s: String) {
        txtStatus.text = "Status: $s"
    }
}
