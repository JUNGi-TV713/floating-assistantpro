package com.floatingassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * Background playback as a proper Android 15 foreground service:
 * foregroundServiceType mediaPlayback is declared in the manifest and
 * passed to startForeground() here. The notification has a Roko action
 * so playback can be stopped from the lock screen / notification shade.
 */
class PlaybackService : Service() {
    companion object {
        const val ACTION_STOP = "com.floatingassistant.STOP"
        const val ACTION_PAUSE = "com.floatingassistant.PAUSE"
        const val CHANNEL_ID = "fa_playback"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP, ACTION_PAUSE -> {
                TTSHelper.stop()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
        }
        val text = intent?.getStringExtra("text")
        val mode = intent?.getStringExtra("mode") ?: "Auto"
        if (!text.isNullOrBlank()) {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                @Suppress("DEPRECATION")
                startForeground(1, buildNotification())
            }
            TTSHelper.speak(this, text, mode) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Sunana", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stopIntent = Intent(this, PlaybackService::class.java).apply { action = ACTION_STOP }
        val stopPi = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Floating Assistant — Sun raha hai")
            .setContentText("Rokne ke liye Roko dabayein")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_media_pause, "Roko", stopPi)
            .setContentIntent(openPi)
            .setOngoing(true)
            .build()
    }
}
