package com.floatingassistant

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup = a ZIP file with backup.json + note image files.
 *
 * This is NOT Google Drive sync: there is no OAuth client, so the user
 * saves this ZIP to Drive manually. That limit is shown honestly in the
 * UI and in the test report. Backup runs ONLY when the user presses
 * Export/Import — never in the background.
 */
object ExportImportHelper {
    suspend fun exportZip(ctx: Context, uri: Uri, db: AppDatabase) {
        val notesJson = JSONArray()
        for (n in db.noteDao().all()) {
            val o = JSONObject()
            o.put("title", n.title)
            o.put("body", n.body)
            o.put("category", n.category)
            o.put("pinned", n.pinned)
            o.put("image", File(n.image).name)
            notesJson.put(o)
        }
        val histJson = JSONArray()
        for (h in db.historyDao().all()) {
            val o = JSONObject()
            o.put("text", h.text)
            histJson.put(o)
        }
        val root = JSONObject()
        root.put("notes", notesJson)
        root.put("history", histJson)

        ctx.contentResolver.openOutputStream(uri)?.use { os ->
            ZipOutputStream(os).use { zos ->
                zos.putNextEntry(ZipEntry("backup.json"))
                zos.write(root.toString().toByteArray(Charsets.UTF_8))
                zos.closeEntry()
                val dir = File(ctx.filesDir, "images")
                if (dir.exists()) {
                    dir.listFiles()?.forEach { f ->
                        zos.putNextEntry(ZipEntry("images/" + f.name))
                        FileInputStream(f).use { input -> input.copyTo(zos) }
                        zos.closeEntry()
                    }
                }
            }
        }
    }

    suspend fun importZip(ctx: Context, uri: Uri, db: AppDatabase): String {
        var jsonText: String? = null
        val dir = File(ctx.filesDir, "images")
        dir.mkdirs()
        ctx.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (entry.name == "backup.json") {
                        jsonText = zis.readBytes().toString(Charsets.UTF_8)
                    } else if (entry.name.startsWith("images/")) {
                        val out = File(dir, File(entry.name).name)
                        FileOutputStream(out).use { fos -> zis.copyTo(fos) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }
        if (jsonText == null) return "ZIP mein backup.json nahi mili"
        val root = JSONObject(jsonText)
        var notes = 0
        var hist = 0
        val notesArr = root.optJSONArray("notes") ?: JSONArray()
        for (i in 0 until notesArr.length()) {
            val o = notesArr.getJSONObject(i)
            val imageName = o.optString("image", "")
            val imagePath = if (imageName.isNotBlank()) {
                val f = File(dir, imageName)
                if (f.exists()) f.absolutePath else ""
            } else ""
            db.noteDao().insert(
                NoteEntity(
                    title = o.optString("title", "Imported Note"),
                    body = o.optString("body", ""),
                    category = o.optString("category", "Imported"),
                    pinned = o.optInt("pinned", 0),
                    image = imagePath
                )
            )
            notes++
        }
        val histArr = root.optJSONArray("history") ?: JSONArray()
        for (i in 0 until histArr.length()) {
            val text = histArr.getJSONObject(i).optString("text", "")
            if (text.isNotBlank()) {
                db.historyDao().insert(HistoryEntity(text = text))
                hist++
            }
        }
        return "Import ho gaya: $notes notes, $hist history"
    }
}
