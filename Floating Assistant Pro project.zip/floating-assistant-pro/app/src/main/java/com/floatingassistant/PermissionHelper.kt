package com.floatingassistant

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.core.content.ContextCompat

/**
 * The permission system — the top priority of this rebuild.
 *
 * Every step is shown one at a time in PermissionSetupActivity, in easy
 * Roman Urdu, with: plain name, WHY it is needed, what will NOT work if
 * denied, live status, an Allow button, a Skip button and a Re-check
 * button. A feature that needs a permission must check it at runtime
 * and, if missing, show the reason + a button to the correct settings
 * screen. It must never silently fail and never crash.
 *
 * Android 15 routes used here:
 * - POST_NOTIFICATIONS, RECEIVE_SMS, READ_SMS, RECORD_AUDIO, CAMERA,
 *   READ_MEDIA_IMAGES: normal runtime permission requests.
 * - SYSTEM_ALERT_WINDOW: Settings.ACTION_MANAGE_OVERLAY_PERMISSION
 *   (there is no runtime dialog for this one).
 * - Accessibility: BIND_ACCESSIBILITY_SERVICE, opened through the
 *   system Accessibility settings page. OPTIONAL.
 * - Battery exemption: the system battery-optimisation settings page
 *   (ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), OPTIONAL, no
 *   special permission requested.
 * - Foreground playback: declared with foregroundServiceType
 *   mediaPlayback in the manifest and passed to startForeground();
 *   it needs the notification permission, so it is explained on the
 *   notification step rather than as a separate dialog.
 */
object PermissionHelper {

    enum class Kind { RUNTIME, OVERLAY, ACCESSIBILITY, BATTERY, INFO }

    data class Step(
        val id: String,
        val title: String,
        val why: String,
        val ifDenied: String,
        val kind: Kind,
        val runtimePermissions: List<String> = emptyList(),
        val optional: Boolean = false
    )

    fun steps(): List<Step> = listOf(
        Step(
            id = "notifications",
            title = "Notification ki ijazat",
            why = "Background mein sunana aur player ka Roko button dikhane ke liye. Android 13 se ye ijazat alag se mangni parti hai.",
            ifDenied = "Sunana background mein nahi chalega aur notification se Roko nahi hoga.",
            kind = Kind.RUNTIME,
            runtimePermissions = if (Build.VERSION.SDK_INT >= 33) {
                listOf(Manifest.permission.POST_NOTIFICATIONS)
            } else emptyList()
        ),
        Step(
            id = "background_playback",
            title = "Background mein sunana (jaankari)",
            why = "Ye app sunane ke liye Android ki foreground service use karti hai. Iske liye alag se koi dialog nahi aata — notification wali ijazat hi kaafi hai. App band karne par bhi sunana chalta rahega jab tak aap Roko na dabayen.",
            ifDenied = "Agar notification ki ijazat na mile, to background sunana bhi nahi chalega.",
            kind = Kind.INFO
        ),
        Step(
            id = "overlay",
            title = "Doosri apps ke upar dikhana (Floating Button)",
            why = "Floating button har app ke upar dikhane ke liye. Iske baghair app sirf apne andar chalegi, doosri app par button nahi aayega.",
            ifDenied = "Floating button nahi chalega. Sirf app khol kar kaam hoga.",
            kind = Kind.OVERLAY
        ),
        Step(
            id = "sms",
            title = "SMS parhna (sirf OTP ke liye)",
            why = "SMS se OTP nikal kar ek tap par copy karne ke liye. OTP kabhi save nahi hota, screen band hote hi khatam ho jata hai.",
            ifDenied = "SMS se OTP khud nahi aayega. Aap manual OTP wali screen se OTP copy kar sakte hain.",
            kind = Kind.RUNTIME,
            runtimePermissions = listOf(
                Manifest.permission.RECEIVE_SMS,
                Manifest.permission.READ_SMS
            )
        ),
        Step(
            id = "audio",
            title = "Microphone (bol kar likhna)",
            why = "Bol kar text likhne aur bol kar hukum dene ke liye.",
            ifDenied = "Bol kar likhna nahi chalega. Likh kar kaam hoga.",
            kind = Kind.RUNTIME,
            runtimePermissions = listOf(Manifest.permission.RECORD_AUDIO)
        ),
        Step(
            id = "camera",
            title = "Camera (photo se text / note)",
            why = "Note mein photo lagane aur photo se text nikalne ke liye.",
            ifDenied = "Photo wala kaam nahi chalega. Text note chalega.",
            kind = Kind.RUNTIME,
            runtimePermissions = listOf(Manifest.permission.CAMERA)
        ),
        Step(
            id = "images",
            title = "Gallery ki photos (note mein image)",
            why = "Gallery se photo chun kar note mein lagane ke liye.",
            ifDenied = "Gallery se photo nahi lagegi. Camera ya text note chalega.",
            kind = Kind.RUNTIME,
            runtimePermissions = listOf(Manifest.permission.READ_MEDIA_IMAGES)
        ),
        Step(
            id = "accessibility",
            title = "Accessibility (tap kar ke sunana) — OPTIONAL",
            why = "Screen ke kisi text par tap kar ke usay sunane aur split screen ki koshish ke liye. Ye OPTIONAL hai.",
            ifDenied = "Tap wala sunana aur split screen ki koshish nahi chalegi. Copy wala sunana chalega.",
            kind = Kind.ACCESSIBILITY,
            optional = true
        ),
        Step(
            id = "battery",
            title = "Battery setting (background sunana) — OPTIONAL",
            why = "Kuch phone background sunana band kar dete hain. Is setting se app ko battery optimisation se bahar rakha ja sakta hai, taake sunana beech mein na ruke.",
            ifDenied = "Sunana kabhi kabhi beech mein ruk sakta hai, lekin app chalegi.",
            kind = Kind.BATTERY,
            optional = true
        )
    )

    fun isGranted(ctx: Context, step: Step): Boolean = when (step.kind) {
        Kind.RUNTIME -> step.runtimePermissions.all {
            ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
        }
        Kind.OVERLAY -> Settings.canDrawOverlays(ctx)
        Kind.ACCESSIBILITY -> isAccessibilityEnabled(ctx)
        Kind.BATTERY -> isBatteryExempt(ctx)
        Kind.INFO -> true
    }

    fun statusText(ctx: Context, step: Step): String = when {
        step.kind == Kind.INFO -> "Maloom hai — iske liye alag ijazat nahi chahiye"
        isGranted(ctx, step) -> "Allowed — mil gayi"
        else -> "Abhi nahi mili" + if (step.optional) " (optional, chora ja sakta hai)" else ""
    }

    fun isAccessibilityEnabled(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
            ?: return false
        val expected = "${ctx.packageName}/${ReadAloudAccessibilityService::class.java.name}"
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_SPOKEN)
            .any { it.id == expected }
    }

    fun isBatteryExempt(ctx: Context): Boolean {
        val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isIgnoringBatteryOptimizations(ctx.packageName)
    }

    /** Intent for the correct system screen for a special (non-runtime) step. */
    fun settingsIntent(ctx: Context, step: Step): Intent? = when (step.kind) {
        Kind.OVERLAY -> Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${ctx.packageName}")
        )
        Kind.ACCESSIBILITY -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        Kind.BATTERY -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        else -> null
    }

    fun openAppSettings(ctx: Context) {
        val intent = Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${ctx.packageName}")
        )
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    /**
     * True when the user has permanently denied a runtime permission
     * ("Don't ask again") — then only the system Settings page can help.
     */
    fun isPermanentlyDenied(activity: android.app.Activity, step: Step): Boolean {
        return step.kind == Kind.RUNTIME && step.runtimePermissions.any { perm ->
            ContextCompat.checkSelfPermission(activity, perm) != PackageManager.PERMISSION_GRANTED &&
                !activity.shouldShowRequestPermissionRationale(perm)
        }
    }
}
