package com.floatingassistant

/**
 * OTP extraction, in memory only. This class stores nothing, and callers
 * must never store its result in a database, note, history or file.
 */
object OtpUtil {
    private val otpRegex = Regex("\\b\\d{4,6}\\b")

    fun findOtp(text: String?): String? {
        if (text.isNullOrBlank()) return null
        return otpRegex.find(text)?.value
    }
}
