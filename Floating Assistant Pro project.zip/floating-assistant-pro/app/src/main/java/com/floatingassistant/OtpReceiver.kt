package com.floatingassistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsMessage

/**
 * SMS OTP receiver. The OTP is passed in memory only, via an Intent
 * extra, to OtpActivity, which clears it when it closes. It is never
 * written to the database, notes, history or any file.
 */
class OtpReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.SMS_RECEIVED") return
        val bundle = intent.extras ?: return
        val pdus = bundle.get("pdus") as? Array<*> ?: return
        val format = bundle.getString("format")
        val all = StringBuilder()
        for (p in pdus) {
            val bytes = p as? ByteArray ?: continue
            val msg = if (Build.VERSION.SDK_INT >= 23) {
                SmsMessage.createFromPdu(bytes, format)
            } else {
                @Suppress("DEPRECATION")
                SmsMessage.createFromPdu(bytes)
            }
            msg.messageBody?.let { all.append(it).append(" ") }
        }
        val otp = OtpUtil.findOtp(all.toString()) ?: return
        val i = Intent(ctx, OtpActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("otp", otp)
        }
        ctx.startActivity(i)
    }
}
