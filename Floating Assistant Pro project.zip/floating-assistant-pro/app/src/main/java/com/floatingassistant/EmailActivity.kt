package com.floatingassistant

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/**
 * Email small window — paste-text only, labelled honestly in the layout.
 * Real Gmail needs a Google OAuth setup, which does not exist yet, so
 * no fake Gmail login is shown here. The user can paste email text,
 * read it aloud, extract an OTP from it (memory only, never saved),
 * or save the text as a note.
 */
class EmailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_email)
        val edt = findViewById<EditText>(R.id.edtEmailText)
        val result = findViewById<TextView>(R.id.txtEmailResult)
        val db = AppDatabase.get(this)

        findViewById<Button>(R.id.btnEmailSpeak).setOnClickListener {
            val text = edt.text.toString()
            if (text.isBlank()) {
                Toast.makeText(this, "Pehle email ka text paste karein", Toast.LENGTH_SHORT).show()
            } else {
                speakViaService(text)
            }
        }
        findViewById<Button>(R.id.btnEmailOtp).setOnClickListener {
            val code = OtpUtil.findOtp(edt.text.toString())
            if (code == null) {
                result.text = "Is text mein OTP nahi mila."
            } else {
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("OTP", code))
                result.text = "OTP copy ho gaya: $code — ye kahin save nahi hua."
            }
        }
        findViewById<Button>(R.id.btnEmailSave).setOnClickListener {
            val text = edt.text.toString()
            if (text.isBlank()) {
                Toast.makeText(this, "Pehle text paste karein", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            lifecycleScope.launch {
                db.noteDao().insert(
                    NoteEntity(title = "Email Note", body = text, category = "Email")
                )
                Toast.makeText(this@EmailActivity, "Note mein save ho gaya", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun speakViaService(text: String) {
        val i = android.content.Intent(this, PlaybackService::class.java).apply {
            putExtra("text", text)
            putExtra("mode", Prefs.lang(this@EmailActivity))
        }
        startService(i)
    }
}
