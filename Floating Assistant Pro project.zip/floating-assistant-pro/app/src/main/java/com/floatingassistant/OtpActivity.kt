package com.floatingassistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/**
 * OTP popup. The code lives ONLY in a local variable and in the
 * TextView. onDestroy clears the view. It is never written to the
 * database, notes, history or any file.
 */
class OtpActivity : AppCompatActivity() {
    private var otp: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp)
        otp = intent.getStringExtra("otp")
        findViewById<TextView>(R.id.txtOtp).text = otp ?: ""
        findViewById<Button>(R.id.btnOtpCopy).setOnClickListener {
            val code = otp
            if (!code.isNullOrBlank()) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("OTP", code))
                Toast.makeText(this, "OTP copy ho gaya, kahin save nahi hua", Toast.LENGTH_SHORT).show()
            }
            finish()
        }
        findViewById<Button>(R.id.btnOtpClose).setOnClickListener { finish() }
    }

    override fun onDestroy() {
        otp = null
        findViewById<TextView>(R.id.txtOtp)?.text = ""
        super.onDestroy()
    }
}
