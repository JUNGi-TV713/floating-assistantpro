package com.floatingassistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

/**
 * Note editor: text, category, pin, image, speak, copy, save, delete.
 * Delete happens ONLY from the Delete button, after confirmation.
 * OCR: ML Kit on-device text recognition. If the model/text cannot be
 * read, the app says so honestly instead of inventing text.
 */
class NoteEditActivity : AppCompatActivity() {
    private var noteId: Long = -1
    private var imagePath: String = ""
    private var pickedImageUri: android.net.Uri? = null

    private lateinit var edtTitle: EditText
    private lateinit var edtBody: EditText
    private lateinit var spCat: Spinner
    private lateinit var chkPin: CheckBox
    private lateinit var img: ImageView
    private lateinit var txtStatus: TextView

    private val cats = arrayOf(
        "Roz ke jumle", "Email / Address", "AI Prompts",
        "Kaam ki baatein", "Favourite", "Email", "Imported"
    )

    private val pickImage = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri == null) return@registerForActivityResult
        pickedImageUri = uri
        try {
            val input = contentResolver.openInputStream(uri) ?: return@registerForActivityResult
            val bm = BitmapFactory.decodeStream(input)
            input.close()
            if (bm == null) {
                toast("Photo nahi khuli")
                return@registerForActivityResult
            }
            val dir = File(filesDir, "images")
            dir.mkdirs()
            val out = File(dir, "img_${System.currentTimeMillis()}.jpg")
            FileOutputStream(out).use { fos ->
                bm.compress(Bitmap.CompressFormat.JPEG, 70, fos)
            }
            imagePath = out.absolutePath
            showImage()
            toast("Photo lag gayi. Ab 'Photo se text nikalo' dabayein to text bhi aa jayega.")
        } catch (e: Exception) {
            toast("Photo nahi lagi: ${e.message}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note_edit)
        edtTitle = findViewById(R.id.edtTitle)
        edtBody = findViewById(R.id.edtBody)
        spCat = findViewById(R.id.spCategory)
        chkPin = findViewById(R.id.chkPin)
        img = findViewById(R.id.imgNote)
        txtStatus = findViewById(R.id.txtNoteStatus)
        spCat.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, cats)

        val db = AppDatabase.get(this)
        noteId = intent.getLongExtra("noteId", -1)
        intent.getStringExtra("presetText")?.let { edtBody.setText(it) }
        if (noteId >= 0) {
            lifecycleScope.launch {
                val n = db.noteDao().byId(noteId)
                if (n != null) {
                    edtTitle.setText(n.title)
                    edtBody.setText(n.body)
                    chkPin.isChecked = n.pinned == 1
                    imagePath = n.image
                    val idx = cats.indexOf(n.category)
                    if (idx >= 0) spCat.setSelection(idx)
                    showImage()
                }
            }
        }

        click(R.id.btnPickImage, "Photo lagao") {
            if (!PermissionHelper.isGranted(
                    this,
                    PermissionHelper.steps().first { it.id == "images" }
                )
            ) {
                toast("Pehle Permission Setup mein Gallery ki ijazat dein, warna photo nahi lagegi.")
            }
            pickImage.launch("image/*")
        }
        click(R.id.btnNoteOcr, "Photo se text nikalo") { runOcr() }
        click(R.id.btnNoteSpeak, "Note sunao") { speakViaService(edtBody.text.toString()) }
        click(R.id.btnNoteCopy, "Note Copy karo") {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Note", edtBody.text.toString()))
            toast("Note copy ho gaya")
        }
        click(R.id.btnNoteSave, "Save karo") {
            val title = edtTitle.text.toString().trim().ifEmpty { "Note" }
            val body = edtBody.text.toString()
            val category = cats[spCat.selectedItemPosition]
            val pinned = if (chkPin.isChecked) 1 else 0
            lifecycleScope.launch {
                if (noteId >= 0) {
                    val old = db.noteDao().byId(noteId)
                    if (old != null) {
                        db.noteDao().update(
                            old.copy(
                                title = title, body = body, category = category,
                                pinned = pinned, image = imagePath,
                                updated = System.currentTimeMillis()
                            )
                        )
                    }
                } else {
                    db.noteDao().insert(
                        NoteEntity(title = title, body = body, category = category, pinned = pinned, image = imagePath)
                    )
                }
                toast("Save ho gaya")
                finish()
            }
        }
        click(R.id.btnNoteDelete, "Delete karo") {
            if (noteId < 0) {
                finish()
                return@click
            }
            AlertDialog.Builder(this)
                .setTitle("Delete karein?")
                .setMessage("Kya aap ye note delete karna chahte hain? Ye sirf aapke is button se delete hoga.")
                .setPositiveButton("Haan, Delete karo") { _, _ ->
                    lifecycleScope.launch {
                        db.noteDao().deleteById(noteId)
                        finish()
                    }
                }
                .setNegativeButton("Nahi", null)
                .show()
        }
    }

    private fun runOcr() {
        val uri = pickedImageUri
        if (uri == null && imagePath.isBlank()) {
            toast("Pehle Photo lagao, phir OCR dabayein")
            return
        }
        try {
            val image = if (uri != null) {
                InputImage.fromFilePath(this, uri)
            } else {
                InputImage.fromFilePath(this, android.net.Uri.fromFile(File(imagePath)))
            }
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val found = visionText.text.trim()
                    if (found.isEmpty()) {
                        txtStatus.text = "Photo mein koi text nahi mila."
                        toast("Photo mein koi text nahi mila")
                    } else {
                        val current = edtBody.text.toString()
                        edtBody.setText(if (current.isBlank()) found else "$current\n$found")
                        txtStatus.text = "Photo se text mil gaya."
                        toast("Photo se text mil gaya")
                    }
                }
                .addOnFailureListener { e ->
                    txtStatus.text = "OCR nahi hua: ${e.message}. Model download nahi hua ho to dobara koshish karein."
                    toast("OCR nahi hua, dobara koshish karein")
                }
        } catch (e: Exception) {
            toast("OCR nahi hua: ${e.message}")
        }
    }

    private fun showImage() {
        if (imagePath.isNotBlank()) {
            val f = File(imagePath)
            if (f.exists()) {
                val bm = BitmapFactory.decodeFile(imagePath)
                if (bm != null) {
                    img.setImageBitmap(bm)
                    img.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun speakViaService(text: String) {
        if (text.isBlank()) return
        val i = Intent(this, PlaybackService::class.java).apply {
            putExtra("text", text)
            putExtra("mode", Prefs.lang(this@NoteEditActivity))
        }
        startService(i)
    }

    private fun click(id: Int, label: String, action: () -> Unit) {
        findViewById<Button>(id).setOnClickListener {
            TTSHelper.speakLabel(this, label)
            action()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
