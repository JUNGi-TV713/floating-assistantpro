package com.floatingassistant

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Notebook PIN storage.
 *
 * Preferred: EncryptedSharedPreferences (AES256). If encrypted storage
 * cannot be created on a particular phone, the PIN falls back to private
 * SharedPreferences and [isEncrypted] becomes false — the app must then
 * tell the user honestly (see MainActivity / test report) instead of
 * claiming encryption that is not in effect.
 *
 * The PIN is only ever written when the user taps "PIN Save karo".
 */
object PinStore {
    private const val ENC_FILE = "fa_pin_enc"
    private const val PLAIN_FILE = "fa_pin_plain"

    /** True only if the currently stored PIN lives in encrypted storage. */
    fun isEncrypted(ctx: Context): Boolean =
        ctx.getSharedPreferences("fa_prefs", Context.MODE_PRIVATE)
            .getBoolean("pinEncrypted", false)

    private fun encryptedPrefs(ctx: Context) = try {
        val masterKey = MasterKey.Builder(ctx)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            ctx,
            ENC_FILE,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        null
    }

    fun getPin(ctx: Context): String {
        val enc = encryptedPrefs(ctx)
        if (enc != null) {
            val v = enc.getString("pin", null)
            if (v != null) return v
        }
        return ctx.getSharedPreferences(PLAIN_FILE, Context.MODE_PRIVATE)
            .getString("pin", "") ?: ""
    }

    fun setPin(ctx: Context, pin: String) {
        val enc = encryptedPrefs(ctx)
        val prefs = ctx.getSharedPreferences("fa_prefs", Context.MODE_PRIVATE)
        if (enc != null) {
            enc.edit().putString("pin", pin).apply()
            ctx.getSharedPreferences(PLAIN_FILE, Context.MODE_PRIVATE).edit().remove("pin").apply()
            prefs.edit().putBoolean("pinEncrypted", true).apply()
        } else {
            ctx.getSharedPreferences(PLAIN_FILE, Context.MODE_PRIVATE).edit().putString("pin", pin).apply()
            prefs.edit().putBoolean("pinEncrypted", false).apply()
        }
    }
}
