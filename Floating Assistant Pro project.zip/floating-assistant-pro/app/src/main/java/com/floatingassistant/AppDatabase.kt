package com.floatingassistant

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update

/**
 * Room database for notes, copy history and the assistant log.
 *
 * DELIBERATELY ABSENT, by the user's correction of 30 Oct 2026:
 * there is NO expiry column, NO auto-delete job, NO cleanup trigger and
 * NO scheduled deletion anywhere in this file or in the app.
 * Rows disappear only when the user presses a delete button, which calls
 * deleteNote / deleteHistory / deleteAllHistory below.
 */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val category: String,
    val pinned: Int = 0,
    val image: String = "",
    val created: Long = System.currentTimeMillis(),
    val updated: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val created: Long = System.currentTimeMillis()
)

@Entity(tableName = "assistant_log")
data class AssistantLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val action: String,
    val created: Long = System.currentTimeMillis()
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE title LIKE '%' || :q || '%' OR body LIKE '%' || :q || '%' OR category LIKE '%' || :q || '%' ORDER BY pinned DESC, updated DESC")
    suspend fun search(q: String): List<NoteEntity>

    @Query("SELECT * FROM notes ORDER BY pinned DESC, updated DESC")
    suspend fun all(): List<NoteEntity>

    @Query("SELECT * FROM notes WHERE id = :id LIMIT 1")
    suspend fun byId(id: Long): NoteEntity?

    @Insert
    suspend fun insert(note: NoteEntity): Long

    @Update
    suspend fun update(note: NoteEntity)

    @Delete
    suspend fun delete(note: NoteEntity)

    @Query("DELETE FROM notes WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY id DESC")
    suspend fun all(): List<HistoryEntity>

    @Insert
    suspend fun insert(item: HistoryEntity): Long

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun deleteById(id: Long)

    // Called ONLY from a user-confirmed delete-all button. Never called
    // automatically, never called on a timer, never called on startup.
    @Query("DELETE FROM history")
    suspend fun deleteAll()
}

@Dao
interface AssistantLogDao {
    @Query("SELECT * FROM assistant_log ORDER BY id DESC LIMIT 30")
    suspend fun recent(): List<AssistantLogEntity>

    @Insert
    suspend fun insert(log: AssistantLogEntity)
}

@Database(
    entities = [NoteEntity::class, HistoryEntity::class, AssistantLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun noteDao(): NoteDao
    abstract fun historyDao(): HistoryDao
    abstract fun assistantLogDao(): AssistantLogDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(ctx: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                ctx.applicationContext,
                AppDatabase::class.java,
                "floating_assistant.db"
            ).build().also { instance = it }
        }
    }
}
