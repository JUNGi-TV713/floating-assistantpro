package com.floatingassistant

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

/** Plain-language privacy screen, in Roman Urdu. See layout for text. */
class PrivacyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy)
        findViewById<Button>(R.id.btnPrivacyBack).setOnClickListener {
            TTSHelper.speakLabel(this, "Wapas jao")
            finish()
        }
    }
}
