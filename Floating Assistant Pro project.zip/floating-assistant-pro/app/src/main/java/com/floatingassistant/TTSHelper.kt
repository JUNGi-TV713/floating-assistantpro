package com.floatingassistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Text-to-speech helper. Urdu is detected by the Arabic-script range
 * (U+0600–U+06FF); everything else defaults to English. Roman Urdu is
 * therefore often read as English — that is exactly why the app also
 * offers a manual Auto / Urdu / English switch (see Prefs.lang).
 * The Urdu (Pakistan) voice data must already be downloaded on the
 * phone, otherwise the engine falls back to English.
 */
object TTSHelper {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var onDone: (() -> Unit)? = null

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            ready = (status == TextToSpeech.SUCCESS)
        }.apply {
            setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { onDone?.invoke() }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) {}
            })
        }
    }

    fun isReady(): Boolean = ready

    fun localeFor(text: String, mode: String): Locale = when (mode) {
        "Urdu" -> Locale("ur", "PK")
        "English" -> Locale.US
        else -> {
            val isUrdu = text.any { it.code in 0x0600..0x06FF }
            if (isUrdu) Locale("ur", "PK") else Locale.US
        }
    }

    fun speak(ctx: Context, text: String, mode: String, done: (() -> Unit)? = null) {
        init(ctx)
        if (text.isBlank()) return
        val engine = tts ?: return
        onDone = done
        val loc = localeFor(text, mode)
        val r = engine.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            engine.setLanguage(Locale.US)
        }
        engine.setSpeechRate(Prefs.speed(ctx))
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "fa1")
    }

    /** Short spoken label for a button, queued behind nothing long. */
    fun speakLabel(ctx: Context, label: String) {
        if (!Prefs.buttonVoice(ctx)) return
        init(ctx)
        val engine = tts ?: return
        if (!ready) return
        engine.setLanguage(Locale("ur", "PK"))
        engine.setSpeechRate(1.0f)
        engine.speak(label, TextToSpeech.QUEUE_ADD, null, "label")
    }

    fun stop() {
        tts?.stop()
    }
}
