package com.floatingassistant

import android.content.Context

/**
 * Simple user settings, stored in private SharedPreferences.
 * NOTE: The notebook PIN itself is NOT stored here — see PinStore.kt.
 * Nothing here auto-deletes anything, and there is no expiry field.
 */
object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("fa_prefs", Context.MODE_PRIVATE)

    fun lang(ctx: Context): String = p(ctx).getString("lang", "Auto") ?: "Auto"
    fun setLang(ctx: Context, v: String) { p(ctx).edit().putString("lang", v).apply() }

    fun speed(ctx: Context): Float = when (p(ctx).getString("speed", "Normal")) {
        "Dheemi" -> 0.75f
        "Tez" -> 1.25f
        else -> 1.0f
    }
    fun speedName(ctx: Context): String = p(ctx).getString("speed", "Normal") ?: "Normal"
    fun setSpeedName(ctx: Context, v: String) { p(ctx).edit().putString("speed", v).apply() }

    fun buttonVoice(ctx: Context): Boolean = p(ctx).getBoolean("buttonVoice", true)
    fun dark(ctx: Context): Boolean = p(ctx).getBoolean("dark", false)
    fun setDark(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("dark", v).apply() }

    fun lockOn(ctx: Context): Boolean = p(ctx).getBoolean("lockOn", false)
    fun setLockOn(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("lockOn", v).apply() }
    fun unlocked(ctx: Context): Boolean = p(ctx).getBoolean("unlocked", false)
    fun setUnlocked(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("unlocked", v).apply() }

    fun tapToRead(ctx: Context): Boolean = p(ctx).getBoolean("tapToRead", false)
    fun setTapToRead(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("tapToRead", v).apply() }

    fun buttonSize(ctx: Context): Int = when (p(ctx).getString("buttonSize", "Medium")) {
        "Chota" -> 56
        "Bara" -> 88
        else -> 72
    }
    fun buttonSizeName(ctx: Context): String = p(ctx).getString("buttonSize", "Medium") ?: "Medium"
    fun setButtonSizeName(ctx: Context, v: String) { p(ctx).edit().putString("buttonSize", v).apply() }

    fun setupDone(ctx: Context): Boolean = p(ctx).getBoolean("setupDone", false)
    fun setSetupDone(ctx: Context, v: Boolean) { p(ctx).edit().putBoolean("setupDone", v).apply() }
}
