package com.floatingassistant

import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

/**
 * The always-visible floating button (TYPE_APPLICATION_OVERLAY).
 * Requires SYSTEM_ALERT_WINDOW — MainActivity checks this at runtime
 * and sends the user to the correct settings screen if it is missing,
 * instead of silently failing.
 */
class FloatingService : Service() {
    private var wm: WindowManager? = null
    private var root: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = LayoutInflater.from(this).inflate(R.layout.layout_floating, null)
        val type = if (Build.VERSION.SDK_INT >= 26) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val size = Prefs.buttonSize(this)
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { x = 100; y = 300 }

        val main = root!!.findViewById<Button>(R.id.btnFloatMain)
        main.layoutParams.width = size
        main.layoutParams.height = size
        val menu = root!!.findViewById<LinearLayout>(R.id.floatMenu)
        main.setOnClickListener {
            TTSHelper.speakLabel(this, "Floating menu")
            menu.visibility = if (menu.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
        main.setOnLongClickListener {
            Toast.makeText(
                this,
                "Button chupane ke liye app mein Floating Button band karein",
                Toast.LENGTH_LONG
            ).show()
            true
        }
        root!!.setOnTouchListener(object : View.OnTouchListener {
            private var ox = 0
            private var oy = 0
            private var tx = 0f
            private var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val p = params ?: return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        ox = p.x; oy = p.y; tx = e.rawX; ty = e.rawY
                        return false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = ox + (e.rawX - tx).toInt()
                        p.y = oy + (e.rawY - ty).toInt()
                        wm?.updateViewLayout(root, p)
                        return true
                    }
                }
                return false
            }
        })

        root!!.findViewById<View>(R.id.btnFSpeak).setOnClickListener { speakClipboard() }
        root!!.findViewById<View>(R.id.btnFStop).setOnClickListener {
            TTSHelper.stop()
            stopService(Intent(this, PlaybackService::class.java))
        }
        root!!.findViewById<View>(R.id.btnFNotes).setOnClickListener { openMain("notes") }
        root!!.findViewById<View>(R.id.btnFHistory).setOnClickListener { openMain("history") }
        root!!.findViewById<View>(R.id.btnFApps).setOnClickListener { openMain("apps") }
        root!!.findViewById<View>(R.id.btnFSplit).setOnClickListener {
            val ok = ReadAloudAccessibilityService.toggleSplitScreen()
            Toast.makeText(
                this,
                if (ok) "Split screen ki koshish ho rahi hai"
                else "Split screen ke liye Accessibility on karein, ya phone ki split screen use karein",
                Toast.LENGTH_LONG
            ).show()
        }
        root!!.findViewById<View>(R.id.btnFHide).setOnClickListener { stopSelf() }
        wm?.addView(root, params)
    }

    private fun openMain(tab: String) {
        val i = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("tab", tab)
        }
        startActivity(i)
    }

    private fun speakClipboard() {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clip = cm?.primaryClip
            val t = if (clip != null && clip.itemCount > 0) clip.getItemAt(0).text else null
            if (!t.isNullOrBlank()) {
                val s = Intent(this, PlaybackService::class.java).apply {
                    putExtra("text", t.toString())
                    putExtra("mode", Prefs.lang(this@FloatingService))
                }
                startService(s)
                return
            }
        } catch (e: Exception) {
            // Fall through to the honest message below.
        }
        Toast.makeText(
            this,
            "Clipboard khaali hai ya ijazat nahi. Pehle text copy karein, phir app khol kar Sunao dabayein.",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            wm?.removeView(root)
        } catch (ignored: Exception) {
        }
    }
}
