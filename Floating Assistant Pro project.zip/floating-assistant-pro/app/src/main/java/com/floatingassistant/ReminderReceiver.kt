package com.floatingassistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * User-created reminders only. This is the app's only AlarmManager use;
 * there is no background sync, no background email check and no
 * background data use anywhere in the app.
 */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val text = intent.getStringExtra("text") ?: "Aapka reminder: waqt ho gaya hai"
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("fa_rem", "Reminder", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val notification = NotificationCompat.Builder(ctx, "fa_rem")
            .setContentTitle("Floating Assistant — Reminder")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notification)
        try {
            TTSHelper.speak(ctx, text, Prefs.lang(ctx), null)
        } catch (ignored: Exception) {
        }
    }
}
