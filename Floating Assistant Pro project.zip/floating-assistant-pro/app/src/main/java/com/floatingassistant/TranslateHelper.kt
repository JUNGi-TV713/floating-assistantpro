package com.floatingassistant

import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Translation, with an honest two-level design:
 * 1. ML Kit on-device translate — tried first when the user asks for a
 *    full translation. Its language model is downloaded on the phone
 *    only at that moment. If the model cannot be downloaded, this
 *    returns null and the caller MUST say so.
 * 2. A small built-in dictionary — never presented as a full translator.
 *    Unknown words are kept as-is.
 */
object TranslateHelper {
    private val enToUr = mapOf(
        "hello" to "salam", "hi" to "salam",
        "thank" to "shukriya", "thanks" to "shukriya",
        "you" to "aap", "please" to "meherbani",
        "good" to "acha", "morning" to "subah",
        "today" to "aaj", "tomorrow" to "kal",
        "money" to "paisa", "work" to "kaam",
        "home" to "ghar", "friend" to "dost",
        "water" to "pani", "food" to "khana",
        "yes" to "haan", "no" to "nahi",
        "help" to "madad", "time" to "waqt",
        "love" to "mohabbat", "happy" to "khush"
    )

    fun dictionaryTranslate(text: String): String {
        if (text.isBlank()) return ""
        return text.split("\\s+".toRegex()).joinToString(" ") { word ->
            val clean = word.lowercase().replace("[^a-z]".toRegex(), "")
            enToUr[clean] ?: word
        }
    }

    fun summary(text: String): String {
        val t = text.trim()
        if (t.isEmpty()) return ""
        val parts = t.split(Regex("(?<=[.!?])\\s+"))
        val s = parts.take(2).joinToString(" ").trim()
        val out = if (s.length > 300) s.substring(0, 300) else s
        return out.ifEmpty { t }
    }

    /** Returns the ML Kit translation, or null if the model is unavailable. */
    suspend fun mlTranslate(text: String, toUrdu: Boolean): String? {
        return try {
            val source = if (toUrdu) TranslateLanguage.ENGLISH else TranslateLanguage.URDU
            val target = if (toUrdu) TranslateLanguage.URDU else TranslateLanguage.ENGLISH
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(target)
                .build()
            val translator = Translation.getClient(options)
            try {
                val downloaded: Boolean = suspendCancellableCoroutine { cont ->
                    translator.downloadModelIfNeeded()
                        .addOnSuccessListener { cont.resume(true) }
                        .addOnFailureListener { cont.resume(false) }
                }
                if (!downloaded) return null
                suspendCancellableCoroutine { cont ->
                    translator.translate(text)
                        .addOnSuccessListener { cont.resume(it) }
                        .addOnFailureListener { cont.resume(null) }
                }
            } finally {
                translator.close()
            }
        } catch (e: Exception) {
            null
        }
    }
}
