package com.floatingassistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.lang.ref.WeakReference

/**
 * OPTIONAL Accessibility service.
 * - Tap-to-read: when tap-to-read is enabled in the app, a tapped view's
 *   text (under 500 characters) is spoken aloud.
 * - Split-screen: the system toggle action, used by the app's
 *   Split Screen button. If this service is not running, the app must
 *   show the honest fallback message instead.
 * Nothing here reads WhatsApp or any other app's private messages on
 * its own — it only speaks text from a view the user tapped, or text
 * from the currently active window when the user explicitly asks the
 * floating button to read the screen.
 */
class ReadAloudAccessibilityService : AccessibilityService() {
    companion object {
        private var ref: WeakReference<ReadAloudAccessibilityService>? = null

        fun toggleSplitScreen(): Boolean {
            val s = ref?.get() ?: return false
            return try {
                s.performGlobalAction(GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
            } catch (e: Exception) {
                false
            }
        }

        fun speakActiveWindow(): Boolean {
            val s = ref?.get() ?: return false
            val root = s.rootInActiveWindow ?: return false
            val sb = StringBuilder()
            collectText(root, sb, 2000)
            val text = sb.toString().trim()
            if (text.isEmpty()) return false
            TTSHelper.speak(s, text, Prefs.lang(s), null)
            return true
        }

        private fun collectText(node: AccessibilityNodeInfo?, out: StringBuilder, limit: Int) {
            if (node == null || out.length >= limit) return
            node.text?.let {
                if (it.isNotBlank()) out.append(it).append(" ")
            }
            for (i in 0 until node.childCount) {
                collectText(node.getChild(i), out, limit)
            }
        }
    }

    override fun onServiceConnected() {
        ref = WeakReference(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!Prefs.tapToRead(this)) return
        if (event?.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return
        val sb = StringBuilder()
        event.text?.forEach { sb.append(it).append(" ") }
        val t = sb.toString().trim()
        if (t.isNotEmpty() && t.length < 500) {
            TTSHelper.speak(this, t, Prefs.lang(this), null)
        }
    }

    override fun onInterrupt() {}
}
